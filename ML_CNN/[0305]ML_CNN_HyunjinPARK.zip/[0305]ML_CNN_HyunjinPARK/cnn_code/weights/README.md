# weights

학습된 모델 가중치(`faster_rcnn.pth`)를 저장하는 폴더입니다.
제출 시에는 제외하세요.

