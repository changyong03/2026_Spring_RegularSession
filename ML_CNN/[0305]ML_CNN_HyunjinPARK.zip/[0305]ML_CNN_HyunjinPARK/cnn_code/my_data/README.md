# my_data

`my_photo.jpg` 같은 개인 사진(학습에 포함되지 않은 사진)을 이 폴더에 넣어주세요.

