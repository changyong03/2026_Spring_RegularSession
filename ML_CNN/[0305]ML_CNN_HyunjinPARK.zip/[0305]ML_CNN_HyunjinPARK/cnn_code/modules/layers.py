"""
Basic layers for Part 1.

complete TODO 1~2.
"""

from __future__ import annotations

import numpy as np

class Linear:
    def __init__(self, in_features: int, out_features: int) -> None:
        scale = np.sqrt(2.0 / max(1, in_features))
        self.W = np.random.randn(in_features, out_features) * scale
        self.b = np.zeros((1, out_features), dtype=np.float64)

        self.x_cache: np.ndarray | None = None
        self.dW = np.zeros_like(self.W)
        self.db = np.zeros_like(self.b)

    def forward(self, x: np.ndarray) -> np.ndarray:
        """
        Linear forward: y = xW + b.
        Args: x: input arry, shape = (batch_size, in_features)
        Returns: x: output arry, shape = (batch_size, out_features)
        """
        self.x_cache = x

        return x @ self.W + self.b

    def backward(self, grad_output: np.ndarray) -> np.ndarray:
        """
        Linear backward: dW = x.T @ grad_output, db = sum(grad_output), grad_input = grad_output @ W.T.
        Args: grad_output , shape = (batch_size, out_features)
        Returns: grad_input, shape = (batch_size, in_features)
        """
        if self.x_cache is None:
            raise RuntimeError("forward를 먼저 호출해야 합니다.")
        x = self.x_cache
        self.dW = x.T @ grad_output
        self.db = np.sum(grad_output, axis=0, keepdims=True)
        grad_input = grad_output @ self.W.T

        return grad_input


class ReLU:
    def __init__(self) -> None:
        self.mask: np.ndarray | None = None

    def forward(self, x: np.ndarray) -> np.ndarray:
        """
        ReLU forward.
        Args: x: input arry, any shape
        Returns: ReLU result, same shape as x
        """
        self.mask = x>0

        return np.maximum(x, 0)
    
    def backward(self, grad_output: np.ndarray) -> np.ndarray:
        """
        ReLU backward.
        Args: grad_output, sane shape as forward input x
        Returns: grad for x, same shape as grad_output
        """
        if self.mask is None:
            raise RuntimeError("forward를 먼저 호출해야 합니다.")
        
        return grad_output * self.mask


class Sigmoid:
    def __init__(self) -> None:
        self.out_cache: np.ndarray | None = None

    def forward(self, x: np.ndarray) -> np.ndarray:
        """
        Sigmoid forward.
        Args: input arry x, any shape
        Returns: Sigmoid output, same shape as input
        """
        self.out_cache = 1 / (1 + np.exp(-x))

        return self.out_cache

    def backward(self, grad_output: np.ndarray) -> np.ndarray:
        """
        Sigmoid backward.
        Args: grad_output, same shape as forward input x
        Returns: grad for x, same shape as grad_output
        """
        if self.out_cache is None:
            raise RuntimeError("forward를 먼저 호출해야 합니다.")
        return grad_output * self.out_cache * (1-self.out_cache)
