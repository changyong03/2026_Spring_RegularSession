"""Optimizers for Part 1."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class SGD:
    params: list[Any]
    lr: float = 1e-2

    def step(self) -> None:
        """SGD updating step to all params."""
        for p in self.params:
            if hasattr(p, "W") and hasattr(p, "dW"):
                p.W[...] -= self.lr * p.dW
            if hasattr(p, "b") and hasattr(p, "db"):
                p.b[...] -= self.lr * p.db

    def zero_grad(self) -> None:
        for p in self.params:
            if hasattr(p, "dW"):
                p.dW[...] = 0
            if hasattr(p, "db"):
                p.db[...] = 0

