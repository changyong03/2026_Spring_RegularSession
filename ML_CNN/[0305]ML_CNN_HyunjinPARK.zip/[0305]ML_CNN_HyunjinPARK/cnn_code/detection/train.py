"""Training script for pedestrian detection (TODO 5)."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Iterable

import torch
from torch.utils.data import DataLoader
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
import torchvision


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from detection.dataset import PennFudanDataset  # noqa: E402


def collate_fn(batch):
    return tuple(zip(*batch))


def to_device(targets: Iterable[dict], device: torch.device) -> list[dict]:
    return [{k: (v.to(device) if hasattr(v, "to") else v) for k, v in t.items()} for t in targets]


def get_model(num_classes: int = 2):
    model = torchvision.models.detection.fasterrcnn_resnet50_fpn()
    in_features = model.roi_heads.box_predictor.cls_score.in_features #input features of the classifier
    model.roi_heads.box_predictor = FastRCNNPredictor(in_features, num_classes) #replace the pre-trained head with a new one (num_classes)
    
    return model

def main() -> None:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    dataset = PennFudanDataset(root=PROJECT_ROOT / "data" / "PennFudanPed")
    loader = DataLoader(dataset, batch_size=2, shuffle=True, collate_fn=collate_fn)

    model = get_model(num_classes=2).to(device)
    optimizer = torch.optim.SGD([p for p in model.parameters() if p.requires_grad], lr=0.005, momentum=0.9, weight_decay=0.0005)
    num_epochs = 5

    for epoch in range(num_epochs):
        model.train()
        epoch_loss = 0.0

        for images, targets in loader:
            images = [image.to(device) for image in images]
            targets = to_device(targets, device)

            loss_dict = model(images, targets)
            losses = sum(loss for loss in loss_dict.values())

            optimizer.zero_grad()
            losses.backward()
            optimizer.step()

            epoch_loss += losses.item()

        avg_loss = epoch_loss / max(len(loader), 1)
        print(f"Epoch [{epoch + 1}/{num_epochs}] loss: {avg_loss:.4f}")

    save_dir = PROJECT_ROOT / "weights"
    save_dir.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), save_dir / "faster_rcnn.pth")
        

    # =============TODO 5:=============
    # - epoch 루프
    # - batch 루프에서 images/targets device 이동
    # - loss_dict 합산 -> backward -> step
    # - epoch별 loss 출력
    # - 종료 후 weights/TODO 5: 학습 루프 구현")


if __name__ == "__main__":
    main()