"""Dataset for PennFudan pedestrian detection (TODO 4)."""

from __future__ import annotations

from pathlib import Path
from typing import Any
import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset


def _default_project_root() -> Path:
    return Path(__file__).resolve().parents[1]


class PennFudanDataset(Dataset):
    def __init__(self, root: str | Path | None = None, transforms=None) -> None:
        project_root = _default_project_root()
        self.root = Path(root) if root else project_root / "data" / "PennFudanPed"
        self.transforms = transforms

        self.img_dir = self.root / "PNGImages"
        self.mask_dir = self.root / "PedMasks"

        if not self.img_dir.exists() or not self.mask_dir.exists():
            raise FileNotFoundError(
                f"PennFudanPed 경로를 찾지 못했습니다: {self.root}\n"
                "data/PennFudanPed/PNGImages, PedMasks 구조를 확인하세요."
            )

        self.imgs = sorted(self.img_dir.glob("*.png"))
        self.masks = sorted(self.mask_dir.glob("*.png"))

    def __len__(self) -> int:
        return len(self.imgs)

    def __getitem__(self, idx: int) -> tuple[torch.Tensor, dict[str, Any]]:
        img_path = self.imgs[idx]
        mask_path = self.masks[idx]

        img = Image.open(img_path).convert("RGB")
        mask = Image.open(mask_path)

        mask_np = np.array(mask)
        obj_ids = np.unique(mask_np)
        actual_obj_ids = obj_ids[obj_ids != 0]
        num_objs = len(actual_obj_ids)
        labels = torch.ones((num_objs,), dtype=torch.int64)
        image_id = torch.tensor([idx])

        masks_np = (mask_np == actual_obj_ids[:, None, None])
        masks_tensor = torch.as_tensor(masks_np, dtype=torch.uint8)

        boxes: list[list[float]] = []

        if num_objs == 0:
            boxes_tensor = torch.zeros((0, 4), dtype=torch.float32)
        else:
            for i in range(num_objs):
                ys, xs = np.where(masks_np[i])
                boxes.append(
                    [
                        float(np.min(xs)),
                        float(np.min(ys)),
                        float(np.max(xs)),
                        float(np.max(ys)),
                    ])
            boxes_tensor = torch.as_tensor(boxes, dtype=torch.float32)

        area =  (boxes_tensor[:, 3] - boxes_tensor[:, 1]) \
             *  (boxes_tensor[:, 2] - boxes_tensor[:, 0])
        
        target: dict[str, Any] = {
            "boxes": boxes_tensor,
            "labels": labels,
            "masks": masks_tensor,
            "image_id": image_id,
            "area": area,
        }

        img = (
            torch.as_tensor(np.array(img), dtype=torch.float32)
            .permute(2, 0, 1)
            .contiguous()
            / 255.0
        )

        return img, target