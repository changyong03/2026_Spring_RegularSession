# 🕵️ 26-1 Deep Learning Assignment: From Scratch to Object Detection

## 📌 과제 개요
해당 과제는 딥러닝의 **기초 원리(Layer 구현)**를 다진 뒤 CV 대표 task 중 **Object Detection(객체 탐지)**까지 확장하는 프로젝트입니다.

- Part 1: Linear/Activation/Optimizer를 직접 구현
- Part 2: Faster R-CNN 기반 **보행자 탐지** 학습
- Part 3: 내 사진으로 추론 결과 확인

---

## 🎯 핵심 목표
- **Part 1 (Basics)**: `Linear`, `ReLU`, `Sigmoid`, `SGD`의 동작 원리 이해
- **Part 2 (Application)**: `Faster R-CNN` 파인튜닝으로 보행자 탐지 모델 학습
- **Part 3 (Inference)**: 학습된 모델이 내 사진에서 사람을 탐지하는지 확인

---

## 🛠️ 1. (로컬 환경에서 실행하는 경우에만 해당됨 아니면 1번 항목 무시) 개발 환경 설정
=> GPU있는 경우만 해당..! 해당의 경우 개발환경을 세팅하는데 익숙해지는 목적의 테스크로 사용하시면 됩니다
=> 노트북으로 돌리는 경우나 GPU가 없으면 매우 오래걸림
=> 노트북 환경의 경우 colab과 vessl 실습의 목적도 있는 task이니 colab이나 vessl 사용을 적극 권장함(colab과 vessl에서는 대부분 다 설치가 되어있어 따로 개발환경 세팅을 신경 쓰지 않으셔도 됩니다.)
=>> colab 사용 시 google drive 혹은 vessl 저장소에 cnn_code 파일 자체 전체를 업로드하여 실행할 것
### 1-1. 프로젝트 폴더 이동
```bash
cd [과제 폴더 경로]
```
### 1-2. 가상환경
#### [방법 A] Conda (권장)
```bash
conda create -n dl_assignment python=3.10
conda activate dl_assignment
```
#### [방법 B] venv
```bash
# Windows
python -m venv .venv
.\.venv\Scripts\activate

# Mac / Linux
python3 -m venv .venv
source .venv/bin/activate
```
### 1-3. 패키지 설치
```bash
pip install -r requirements.txt
```
---

## 📂 2. 폴더 구조
```text
.
├── modules/
│   ├── layers.py          # TODO 1~2
│   └── optimizer.py       # TODO 3
├── detection/
│   ├── dataset.py         # TODO 4
│   └── train.py           # TODO 5 (모델 구성 + 학습 루프)
├── data/                  # PennFudanPed (제출 시 제외)
├── my_data/               # 내 사진
├── weights/               # 학습 가중치 (제출 시 제외)
├── main_inference.ipynb   # 최종 실행 노트북
└── requirements.txt
```

> 이 템플릿의 `.py`와 `.ipynb`는 **최상위 폴더명을 혹시 `cnn_code`로 저장하지 아니하여도** 실행되도록 작성되어 있습니다.
---

## 📝 3. TODO List

### [Part 1] Basic Layers
- [ ] TODO 1 (`modules/layers.py`): `Linear.forward`, `Linear.backward`
- [ ] TODO 2 (`modules/layers.py`): `ReLU`, `Sigmoid`
- [ ] TODO 3 (`modules/optimizer.py`): `SGD` 업데이트

### [Part 2] Object Detection
- [ ] TODO 4 (`detection/dataset.py`): 이미지/마스크 로딩, box 생성
- [ ] TODO 5 (`detection/train.py`): Faster R-CNN 구성 + epoch 학습 루프 구현

---

## 🚀 4. 학습 실행
```bash
python detection/train.py
```
> colab환경에서는 main_inference.ipynb 두 번째 셀까지를 주석을 제거하고 실행하시면 됩니다.
학습 완료 시 `weights/faster_rcnn.pth` 저장을 목표로 합니다.


---

## 🧪 5. 내 사진 추론
1. `my_data/`에 보행자의 전신이 포함된 개인 사진(학습에 사용되지 않은 사진을 의미함, `my_photo.jpg`) 저장 
    => 사람이 걷는 모습이 포함된 사진이 선호되나 불가한 경우 해당 모습이 전혀 포함되지 않는 사진을 넣고 탐지를 제대로 하지 않는 경우도 허용함
2. `main_inference.ipynb` 실행
3. 모델이 사람을 탐지하면 bounding box가 시각화됨

---

### 📤 추가 안내
• **함수를 다작성하였다면 raise로 시작하는줄은 삭제하여야 함**
• **TODO 이외의 줄에서도 디렉토리 경로 등의 수정은 자유롭게 진행 가능**
## ✅ 제출 필수
- (ONLY!!)실행 결과가 포함된 `main_inference.ipynb` (내 사진 결과 필수)

---

## 📬 문의
오류 발생 시 학술부장 여준호에게 질문 남겨주세요.